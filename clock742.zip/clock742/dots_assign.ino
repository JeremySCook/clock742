// dots_assign.ino
// Separator colon between HH and MM.
// AM = light blue, PM = red
// If BREATHING_COLONS is enabled, brightness pulses in and out using millis().
// No pixels.show() here -- committed by the final show() in face0/1/2.

void dots_assign() {
  int dot1 = 55 + faceID * 85;
  int dot2 = 56 + faceID * 85;

#if BREATHING_COLONS
  // Sine wave breath: period ~3 seconds, range 20-255
  float breath = (sin(millis() / 1500.0) + 1.0) / 2.0;  // 0.0 - 1.0
  uint8_t bri = (uint8_t)(20 + breath * 235);

  uint32_t dotColor = is_am
    ? pixels.Color((uint8_t)(60  * bri / 255), (uint8_t)(160 * bri / 255), bri)  // AM: light blue
    : pixels.Color(bri, 0, 0);                                                     // PM: red

#else
  uint32_t dotColor = is_am
    ? pixels.Color(60, 160, 255)   // AM: light blue
    : pixels.Color(220, 0, 0);     // PM: red
#endif

  pixels.setPixelColor(dot1, dotColor);
  pixels.setPixelColor(dot2, dotColor);
}
