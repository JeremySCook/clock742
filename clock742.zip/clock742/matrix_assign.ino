// matrix_assign.ino
// Shared matrix renderer for all three faces.
// 8x3 gravity drain: 1 LED per hour, drains left-to-right bottom-to-top.
// Brightness is constant (MATRIX_BRIGHTNESS), pixel count decreases each hour.

int matrixLED(int col, int row, int faceOffset) {
  int physCol = 8 - col;
  int baseIdx = physCol * 3;
  int ledRow  = (physCol % 2 == 0) ? row : (2 - row);
  return faceOffset + baseIdx + ledRow;
}

void matrix_assign(int r, int g, int b) {
  int litLEDs    = 24 - hour_total;
  int faceOffset = faceID * 85;

  uint32_t onColor = pixels.Color(
    (uint8_t)(r * MATRIX_BRIGHTNESS),
    (uint8_t)(g * MATRIX_BRIGHTNESS),
    (uint8_t)(b * MATRIX_BRIGHTNESS)
  );

  int ledsToLight = litLEDs;
  for (int col = 0; col < 8; col++) {
    for (int row = 2; row >= 0; row--) {
      pixels.setPixelColor(
        matrixLED(col, row, faceOffset),
        ledsToLight-- > 0 ? onColor : 0
      );
    }
  }
}
