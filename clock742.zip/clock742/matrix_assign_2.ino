// matrix_assign_2.ino
// Alias of matrix_assign() for face0 and face2.
// Kept as a separate file so face0/face2 calls remain readable.

void matrix_assign_2(int r, int g, int b) {
  matrix_assign(r, g, b);
}
