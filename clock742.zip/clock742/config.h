// config.h -- user-tunable settings
// Edit these values, then OTA flash to update the clock.
// This file is safe to commit (no secrets).

#ifndef CONFIG_H
#define CONFIG_H

// Home location -- sunrise/sunset for face1 and brightness dimming.
// Default: Palm Harbor, FL
#define HOME_LAT  28.08
#define HOME_LON -82.73

// Digit brightness limits (0-255).
#define BRIGHTNESS_DAY   85
#define BRIGHTNESS_NIGHT 40

// Matrix brightness: 0.0-1.0, relative to digit brightness.
#define MATRIX_BRIGHTNESS 0.7f

// Timezones for each clock face.
// Use POSIX TZ strings. Examples:
//   US Eastern:  "EST5EDT,M3.2.0,M11.1.0"
//   US Central:  "CST6CDT,M3.2.0,M11.1.0"
//   US Mountain: "MST7MDT,M3.2.0,M11.1.0"
//   US Pacific:  "PST8PDT,M3.2.0,M11.1.0"
//   UK:          "GMT0BST,M3.5.0/1,M10.5.0"
//   Germany:     "CET-1CEST,M3.5.0,M10.5.0/3"
//   China:       "CST-8"
//   Japan:       "JST-9"
//   India:       "IST-5:30"
//   Australia E: "AEST-10AEDT,M10.1.0,M4.1.0/3"
#define TZ_FACE0 "CST-8"                      // face0: RIGHT screen
#define TZ_FACE1 "EST5EDT,M3.2.0,M11.1.0"    // face1: CENTER screen (also used for solar brightness)
#define TZ_FACE2 "PST8PDT,M3.2.0,M11.1.0"    // face2: LEFT screen

// Breathing colons: colon brightness pulses in and out.
// Set to 1 to enable, 0 to disable.
#define BREATHING_COLONS 1


// Raise this value if accidental triggers occur on floating pins.
#define TOUCH_THRESHOLD 8000   // Lower = less sensitive. Raise if false triggers occur.

#endif // CONFIG_H
